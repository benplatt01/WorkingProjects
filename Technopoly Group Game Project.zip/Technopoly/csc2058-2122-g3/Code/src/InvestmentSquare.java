public class InvestmentSquare extends Square 
{

	private String name;
	private int location, price, worth;
	private industry industryType;
	private int originalWorth;
	private boolean invested;
	private int investorID;
	private int id;
	private int buildingLevel = 0; // Investment level of a square. 1 is default and will only be changed after investing into it for a second time.


	//Basic squares which don't have a price, type, etc (Go, trade, NULL)
	public InvestmentSquare(int s_id, String s_name, int s_location)
	{
		this.id = s_id;
		this.name = s_name;
		this.location = s_location;

	}

	//Complex squares which the player can invest in
	public InvestmentSquare(String m_name, int m_location, int m_rarity, int m_price, int m_worth, industry m_industryType)
	{
		this.name = m_name;
		this.location = m_location;
		this.industryType = m_industryType;
		this.price = m_price;
		this.worth = m_worth; 
		this.originalWorth = m_worth;
	}

	public int getID()
	{
		return this.id;
	}

	public void setName(String n_name)
	{
		this.name = n_name;
	}

	public void setType(industry n_type)
	{
		this.industryType = n_type;
	}

	public void setPrice(int n_price)
	{
		this.price = n_price;
	}

	public void setWorth(int n_worth)
	{
		this.worth = n_worth;
	}	

	public int getPrice()
	{
		return this.price;
	}

	public int getWorth()
	{
		return this.worth;
	}

	public String getName()
	{
		return this.name;
	}

	public industry getType()
	{
		return this.industryType;
	}

	public boolean getInvested()
	{
		return this.invested;
	}

	public void setInvested(boolean n_invested)
	{
		this.invested = n_invested;
	}

	public int getInvestor()
	{
		return investorID;
	}

	public void setInvestor(int ID)
	{
		this.investorID = ID;
	}

	public int getOriginalWorth()
	{
		return this.originalWorth;
	}

	public int getBuildingLevel() {
		return buildingLevel;
	}

	public void setBuildingLevel(int buildingLevel) {
		this.buildingLevel = buildingLevel;
	}

	public void increaseLevel()
	{
		if(this.buildingLevel < 4)
		{
			double worthToAdd;
			double originalWorthToAdd = originalWorth;
			this.buildingLevel++;
			switch(buildingLevel)
			{
			case 1:
				worthToAdd = originalWorthToAdd / 100 * 25;
				this.worth += worthToAdd;
				System.out.println("You have reinvested resources into your company once you have one server!");
				break;
			case 2: 
				worthToAdd = originalWorthToAdd / 100 * 50;
				this.worth += worthToAdd;
				System.out.println("You have reinvested resources into your company twice you have two servers!");
				break;
			case 3:
				worthToAdd = originalWorthToAdd / 100 * 75;
				this.worth += worthToAdd;
				System.out.println("You have reinvested resources into your company three times you have three servers!");
				break;
			case 4: this.worth = worth + originalWorth;
			System.out.println("Your Technological business has built a Qauntum Computer. You will receive more crypto currency!");
			break;
			default: System.out.println("Error has ocurred");
			break;

			}
		} else 
		{
			System.out.println("Your Technological Business has been invested in enough and you have already have a Corporate Rebrand!");
		}

	}

}
