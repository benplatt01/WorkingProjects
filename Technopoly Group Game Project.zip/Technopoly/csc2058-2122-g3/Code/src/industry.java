
public enum industry 
{
	VR, Cyber, AI, SoftwareDevelopment, GameDev, DataScience, ResearchDev, Financial;
}
