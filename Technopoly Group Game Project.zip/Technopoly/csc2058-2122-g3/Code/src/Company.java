
public class Company {
	int companyInvestments[] = new int[24];
	int companyID;
	String companyName;

	public Company()
	{
		companyID = 0;
		companyName = "NULL";
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Company(String name, int playerID)
	{
		companyID = playerID;
		companyName = name;
	}

	// Adds location of square to investments array.
	public void makeInvestment(int location)
	{
		for(int i = 0; i < companyInvestments.length; i++)
		{
			if(companyInvestments[i] != -1)
			{

			} else if(companyInvestments[i] == -1)
			{
				companyInvestments[i] = location;
				break;
			}
		}
	}
}
