import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Board {

	Square boardPieces[] = new Square[35];
	ArrayList<Player> players;
	ArrayList<Integer> originalWorthSD = new ArrayList<Integer>();
	Scanner scanner = new Scanner(System.in);

	public boolean tradeisActive = false;

	// Constructor
	public Board() 
	{
		Square mySquares[] = new Square[35];
		try {
			File myFile = new File("gameBoard.csv"); 
			Scanner mySc = new Scanner(myFile); 
			int i = 0;
			while (mySc.hasNextLine()) { 
				String input = mySc.nextLine(); 
				String[] parts = input.split(","); 
				int squareType = Integer.parseInt(parts[0]); // Determines the square type via the first number of the row.
				if (squareType == 1) { // If the Square is of Type 1 Investment Square
					String name = parts[1];
					int location = Integer.parseInt(parts[2]);
					int rarity = Integer.parseInt(parts[3]);
					int price = Integer.parseInt(parts[4]);	
					int worth = Integer.parseInt(parts[5]);
					industry newIndustry = null;
					String industryType = parts[6];

					switch (industryType) { // Switch statement to determine what type of industry is stored in row.
					case "VR":
						newIndustry = industry.VR;
						break;
					case "Cyber":
						newIndustry = industry.Cyber;
						break;
					case "AI":
						newIndustry = industry.AI;
						break;
					case "SoftwareDevelopment":
						newIndustry = industry.SoftwareDevelopment;
						break;
					case "GameDev":
						newIndustry = industry.GameDev;
						break;
					case "DataScience":
						newIndustry = industry.DataScience;
						break;
					case "ResearchDev":
						newIndustry = industry.ResearchDev;
						break;
					case "Financial":
						newIndustry = industry.Financial;
						break;
					}

					mySquares[i] = new /* Investment */InvestmentSquare(name, location, rarity, price, worth, newIndustry); // Adds an investment square to the array of squares
					i++;
				} else if (squareType == 0) { // If square is a basic square E.G Go, Trade etc
					int basicID = Integer.parseInt(parts[3]); // Gets Square ID2
					String basicName = parts[1]; // Gets square name
					int basicLocation = Integer.parseInt(parts[2]); // Gets square location
					mySquares[i] = new /* Investment */InvestmentSquare(basicID,basicName, basicLocation); // Adds basic square to array
					i++;
				} else if (squareType == 2) { // If square is a crypto square

					String chanceName = parts[1]; 
					int chanceLocation = Integer.parseInt(parts[2]);
					mySquares[i] = new CryptoSquare(chanceLocation, chanceName); 
					i++;
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace(); 
		}
		boardPieces = mySquares; // Assigns actual board squares to csv generated squares.
	}


	public void setPlayers(ArrayList<Player> arrayList) 
	{
		this.players = arrayList;
	}




	private void taxPlayer(int playerNumber, int location) 
	{

		//check if square is owned by the current player, if so do not tax them.

		if(((InvestmentSquare) boardPieces[location]).getInvestor() == playerNumber)
		{

			System.out.println("You have landed on your own company: " + ((InvestmentSquare) boardPieces[location]).getName());
			System.out.println("You have " + players.get(playerNumber).getBalance() +  "ε");
			if(players.get(playerNumber).getBalance() < ((InvestmentSquare) boardPieces[location]).getPrice())
			{
				System.out.println("You cannot afford to reinvest into this company.");
				players.get(playerNumber).turnComplete = true;
			} 
			else
			{
				System.out.println("Would you like to reinvest in this company to build a server? It will cost " + ((InvestmentSquare) boardPieces[location]).getOriginalWorth() + "ε");
				// Code to build servers on a technology.
				Boolean reinvestBool = false;
				while(reinvestBool != true)
				{
					String reinvestInput = scanner.nextLine();
					if(!reinvestInput.equalsIgnoreCase("yes") && !reinvestInput.equalsIgnoreCase("no"))
					{
						System.out.println("Please enter yes or no!");
					} else if(reinvestInput.equalsIgnoreCase("yes")) 
					{
						players.get(playerNumber).decreaseBalance(((InvestmentSquare) boardPieces[location]).getOriginalWorth());
						((InvestmentSquare) boardPieces[location]).increaseLevel();
						System.out.println("This company is now worth: " + ((InvestmentSquare) boardPieces[location]).getWorth() + "ε");
						reinvestBool = true;

					} else if(reinvestInput.equalsIgnoreCase("no"))
					{
						reinvestBool = true;
					}

				}
			}

		}
		else if(((InvestmentSquare) boardPieces[location]).getInvestor() != playerNumber)
		{
			System.out.println("You have landed on Player: " + ((InvestmentSquare) boardPieces[location]).getInvestor()
					+ "'s company you have to pay taxes to them"); // lets player know where they landed	
			players.get(playerNumber).decreaseBalance(((InvestmentSquare) boardPieces[location]).getWorth());
			players.get(((InvestmentSquare) boardPieces[location]).getInvestor()).increaseBalance(((InvestmentSquare) boardPieces[location]).getWorth());
			System.out.println("You have been taxed " + ((InvestmentSquare) boardPieces[location]).getWorth() + "ε, you now have " + players.get(playerNumber).getBalance() + "ε left");

			// checks if the player goes below 0 and calls the bankruptcy method
			if (players.get(playerNumber).getBalance() <= 0) 
			{
				System.out.println("You have gone Bankrupt!");
				players.get(playerNumber).setBalance(0);


			}

		}

	}


	public void technopolisation(int playerNumber, int numEntered) {
		Scanner sc = new Scanner(System.in);
		int countSD = 0;
		int countDS = 0;
		int countVR = 0;
		int countCyber = 0;
		int countGD = 0;
		int countAI = 0;
		int countFI = 0;
		int countRD = 0;


		{
			//check the players owned properties, if all squares of an industry are owned, give an option to technopolise.
			if (!players.get(playerNumber).monoSD) 
			{

				for(int i = 0; i < players.get(playerNumber).locationsInvested.size(); i++)
				{


					if(((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getType() == industry.SoftwareDevelopment && ((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getBuildingLevel() == 4)
					{
						countSD++;   

						if(countSD == 2)
						{
							players.get(playerNumber).monopolisationAvailable = true;
							if(numEntered == 7)
								System.out.println("You can Technopolise Software Development industry, would you like to?");
							{
								String entry = sc.nextLine();
								if (entry.equalsIgnoreCase("yes"))
								{

									players.get(playerNumber).monoSD = true;
									System.out.println("Technopolising Software Development");
									players.get(playerNumber).monopolisationAvailable = false;
								}
								if (entry.equalsIgnoreCase("no"))
								{

									System.out.println("You have chosen not to Technopolise");

								}
							}	
						} 

					}
				}
			}

			//Technopolising data science 
			if (!players.get(playerNumber).monoDS) 
			{

				for(int i = 0; i < players.get(playerNumber).locationsInvested.size(); i++)
				{


					if(((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getType() == industry.DataScience && ((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getBuildingLevel() == 4)
					{
						countDS++;   

						if(countDS == 3)
						{
							players.get(playerNumber).monopolisationAvailable = true;
							if(numEntered == 7)
								System.out.println("You can Technopolise Data Science industry, would you like to?");
							{
								String entry = sc.nextLine();
								if (entry.equalsIgnoreCase("yes"))
								{

									players.get(playerNumber).monoDS = true;
									System.out.println("Technopolising Data Science");
									players.get(playerNumber).monopolisationAvailable = false;
								}
								if (entry.equalsIgnoreCase("no"))
								{

									System.out.println("You have chosen not to Technopolise");

								}
							}	
						} 

					}
				}
			}

			//Technopolising VR industry
			if (!players.get(playerNumber).monoVR) 
			{

				for(int i = 0; i < players.get(playerNumber).locationsInvested.size(); i++)
				{


					if(((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getType() == industry.VR && ((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getBuildingLevel() == 4)
					{
						countVR++;   

						if(countVR == 3)
						{
							players.get(playerNumber).monopolisationAvailable = true;
							if(numEntered == 7)
								System.out.println("You can Technopolise Virtual Reality industry, would you like to?");
							{
								String entry = sc.nextLine();
								if (entry.equalsIgnoreCase("yes"))
								{

									players.get(playerNumber).monoVR = true;
									System.out.println("Technopolising Virtual Reality");
									players.get(playerNumber).monopolisationAvailable = false;
								}
								if (entry.equalsIgnoreCase("no"))
								{

									System.out.println("You have chosen not to Technopolise");

								}
							}	
						} 

					}
				}
			}

			//Technopolising Cyber industry
			if (!players.get(playerNumber).monoCyber) 
			{

				for(int i = 0; i < players.get(playerNumber).locationsInvested.size(); i++)
				{


					if(((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getType() == industry.Cyber && ((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getBuildingLevel() == 4)
					{
						countCyber++;   

						if(countCyber == 3)
						{
							players.get(playerNumber).monopolisationAvailable = true;
							if(numEntered == 7)
								System.out.println("You can Technopolise Cyber Security industry, would you like to?");
							{
								String entry = sc.nextLine();
								if (entry.equalsIgnoreCase("yes"))
								{

									players.get(playerNumber).monoCyber = true;
									System.out.println("Technopolising Cyber Security");
									players.get(playerNumber).monopolisationAvailable = false;
								}
								if (entry.equalsIgnoreCase("no"))
								{

									System.out.println("You have chosen not to Technopolise");

								}
							}	
						} 

					}
				}
			}
			//Technopolising Games Development industry
			if (!players.get(playerNumber).monoGD) 
			{

				for(int i = 0; i < players.get(playerNumber).locationsInvested.size(); i++)
				{


					if(((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getType() == industry.Cyber && ((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getBuildingLevel() == 4)
					{
						countGD++;   

						if(countGD == 3)
						{
							players.get(playerNumber).monopolisationAvailable = true;
							if(numEntered == 7)
								System.out.println("You can Technopolise Games Development industry, would you like to?");
							{
								String entry = sc.nextLine();
								if (entry.equalsIgnoreCase("yes"))
								{

									players.get(playerNumber).monoGD = true;
									System.out.println("Technopolising Games Development");
									players.get(playerNumber).monopolisationAvailable = false;
								}
								if (entry.equalsIgnoreCase("no"))
								{

									System.out.println("You have chosen not to Technopolise");

								}
							}	
						} 

					}
				}
			}
			//Technopolising AI industry
			if (!players.get(playerNumber).monoAI) 
			{

				for(int i = 0; i < players.get(playerNumber).locationsInvested.size(); i++)
				{


					if(((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getType() == industry.AI && ((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getBuildingLevel() == 4)
					{
						countAI++;   

						if(countAI == 3)
						{
							players.get(playerNumber).monopolisationAvailable = true;
							if(numEntered == 7)
								System.out.println("You can Technopolise Artificial Intelligence industry, would you like to?");
							{
								String entry = sc.nextLine();
								if (entry.equalsIgnoreCase("yes"))
								{

									players.get(playerNumber).monoAI = true;
									System.out.println("Technopolising Artificial Intelligence");
									players.get(playerNumber).monopolisationAvailable = false;
								}
								if (entry.equalsIgnoreCase("no"))
								{

									System.out.println("You have chosen not to Technopolise");

								}
							}	
						} 

					}
				}
			}
			//Technopolising Financial industry
			if (!players.get(playerNumber).monoFI) 
			{

				for(int i = 0; i < players.get(playerNumber).locationsInvested.size(); i++)
				{


					if(((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getType() == industry.AI && ((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getBuildingLevel() == 4)
					{
						countFI++;   

						if(countFI == 3)
						{
							players.get(playerNumber).monopolisationAvailable = true;
							if(numEntered == 7)
								System.out.println("You can Technopolise Financial industry, would you like to?");
							{
								String entry = sc.nextLine();
								if (entry.equalsIgnoreCase("yes"))
								{

									players.get(playerNumber).monoFI = true;
									System.out.println("Technopolising Financial");
									players.get(playerNumber).monopolisationAvailable = false;
								}
								if (entry.equalsIgnoreCase("no"))
								{

									System.out.println("You have chosen not to Technopolise");

								}
							}	
						} 

					}
				}
			}
			//Technopolising Research development industry
			if (!players.get(playerNumber).monoRD) 
			{

				for(int i = 0; i < players.get(playerNumber).locationsInvested.size(); i++)
				{


					if(((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getType() == industry.ResearchDev && ((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getBuildingLevel() == 4)
					{
						countRD++;   

						if(countRD == 2)
						{
							players.get(playerNumber).monopolisationAvailable = true;
							if(numEntered == 7)
								System.out.println("You can Technopolise Financial industry, would you like to?");
							{
								String entry = sc.nextLine();
								if (entry.equalsIgnoreCase("yes"))
								{

									players.get(playerNumber).monoRD = true;
									System.out.println("Technopolising Financial");
									players.get(playerNumber).monopolisationAvailable = false;
								}
								if (entry.equalsIgnoreCase("no"))
								{

									System.out.println("You have chosen not to Technopolise");

								}
							}	
						} 

					}
				}
			}
		}
	}

	public void trade(int location, int playerNumber)
	{
		Scanner sc = new Scanner(System.in); // Opens new scanner to intake numbers
		int playerNumberChosen = 0; // Initialises the player number variable used throughout the algorithm.
		int property1Chosen = 0; 
		int property2Chosen = 0;


		System.out.println("Would you like to trade? Enter yes or no: ");
		String entry = sc.nextLine();

		if(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"))
		{

			do
			{
				System.out.println("Invalid option please enter again: ");
				entry = sc.nextLine();

			}
			while(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"));

		}

		if(entry.equalsIgnoreCase("yes"))
		{
			//choose from players who have at least one property
			ArrayList<Integer> playersWhoHaveProperties = new ArrayList<>();

			for(int i = 0; i < players.size(); i++)
			{

				if(players.get(i).locationsInvested.size() != 0 && i != playerNumber && players.get(playerNumber).getLocationsOwned().size() != 0 )
				{
					playersWhoHaveProperties.add(i);
					System.out.println("Player ID: " + (i + 1) + " name: " + players.get(i).getName()  + " Company Name: " + players.get(i).getCompany().companyName);			  				
				}

			}

			if(playersWhoHaveProperties.size() == 0 && players.get(playerNumber).getLocationsOwned().size() != 0)
			{

				System.out.println("Trading will end as no one else owns a Technological Business");
			}
			else if(players.get(playerNumber).getLocationsOwned().size() == 0)
			{

				System.out.println("Trading will end as you do not own a Technological Business");

			}
			else if(players.get(playerNumber).getLocationsOwned().size() != 0 &&  playersWhoHaveProperties.size() != 0)
			{

				tradeisActive = true;
			}


			if(tradeisActive)
			{
				System.out.println();
				System.out.println("Who would you like to trade with? Enter the players ID: ");

				//input validation to ensure player enters correct ID from the list of valid IDs
				boolean firstTry = true;
				do
				{
					try {
						if (!firstTry) System.out.print("Please enter a valid Player ID: ");
						firstTry = false;
						playerNumberChosen = sc.nextInt();
						playerNumberChosen--;
					}

					catch (InputMismatchException e) {
						sc.nextLine();
					}			
				} while (playerNumberChosen < 0 || playerNumberChosen > players.size() || playerNumberChosen == playerNumber || !playersWhoHaveProperties.contains(playerNumberChosen));

				System.out.println();
				ArrayList<Integer> propertiesOwnedByPlayerChosen = new ArrayList<>();
				System.out.println(players.get(playerNumberChosen).getName() + "'s Properties:");
				for(int j = 0; j < players.get(playerNumberChosen).getLocationsOwned().size(); j++)
				{

					System.out.println("Square ID " + players.get(playerNumberChosen).locationsInvested.get(j) + " Name:" + (((InvestmentSquare) boardPieces[players.get(playerNumberChosen).locationsInvested.get(j)]).getName()));
					propertiesOwnedByPlayerChosen.add(players.get(playerNumberChosen).locationsInvested.get(j));

				}

				System.out.println();
				System.out.println("Please enter the ID of the Technological Business you would like to trade for: ");

				firstTry = true;
				do
				{
					try {
						if (!firstTry) System.out.print("Please enter a valid Technological Business ID: ");
						firstTry = false;
						property1Chosen = sc.nextInt();
					}

					catch (InputMismatchException e) {
						sc.nextLine();
					}	
					System.out.println();
				} while (!propertiesOwnedByPlayerChosen.contains(property1Chosen));

				for(int l = 0; l < players.get(playerNumberChosen).getLocationsOwned().size(); l++)
				{
					if(players.get(playerNumberChosen).locationsInvested.get(l) == property1Chosen) // if the players input is equal to the current index
					{

						System.out.println("You have chosen " + ((InvestmentSquare)boardPieces[property1Chosen]).getName() + " to trade for."); //
						System.out.println(players.get(playerNumberChosen).getName() + " you may now decide if you wish to trade this property for another or not.");
						System.out.println("Do you wish to trade?: Yes/No");

					}
				}
				entry = sc.nextLine();
				if(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"))
				{

					do
					{
						System.out.println("Please enter your option: ");
						entry = sc.nextLine();

					}
					while(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"));

				}

				if(entry.equalsIgnoreCase("no"))
				{
					System.out.println("You have chosen not to trade, trading will end");

				}

				//Display the current players properties so they can choose which one they would like to trade with the playerChosen
				else if(entry.equalsIgnoreCase("yes"))
				{
					ArrayList<Integer> propertiesOwnedByPlayer = new ArrayList<>();
					System.out.println(players.get(playerNumber).getName() + "'s Properties:");
					for(int j = 0; j < players.get(playerNumber).getLocationsOwned().size(); j++)
					{

						System.out.println("Square ID " + players.get(playerNumber).locationsInvested.get(j) + " Name:" + (((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(j)]).getName()));	
						propertiesOwnedByPlayer.add(players.get(playerNumber).locationsInvested.get(j));
					} 

					System.out.println();
					System.out.println("Please enter the ID of the Technological Business you would like to trade for: " + ((InvestmentSquare) boardPieces[property1Chosen]).getName());
					//input validation to make sure the player enters a valid technological business ID
					firstTry = true;
					do
					{
						try {
							if (!firstTry) System.out.print("Please enter a valid Technological Business ID: ");
							firstTry = false;
							property2Chosen = sc.nextInt();
						}

						catch (InputMismatchException e) {
							sc.nextLine();
						}			
					} while (!propertiesOwnedByPlayer.contains(property2Chosen));
					System.out.println();
					for(int l = 0; l < players.get(playerNumber).getLocationsOwned().size(); l++)
					{
						if(players.get(playerNumber).locationsInvested.get(l) == property2Chosen) // if the players input is equal to the current index
						{

							System.out.println("You have chosen " + ((InvestmentSquare)boardPieces[property2Chosen]).getName() + " to trade for."); //
							System.out.println(players.get(playerNumber).getName() + " you may now decide if you wish to trade this property for another or not.");
							System.out.println("Do you wish to trade?: Yes/No");

						}
					}

					entry = sc.nextLine();
					if(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"))
					{

						do
						{
							System.out.println("Please enter your option: ");
							entry = sc.nextLine();

						}
						while(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"));

					}


					//The trade function that swaps both players chosen technological businesses
					if(entry.equalsIgnoreCase("yes"))
					{
						int index1 = 0;
						int index2 = 0;

						//Swap player chosen industry with current player
						if(players.get(playerNumber).locationsInvested.contains(property2Chosen))
						{

							index1 = players.get(playerNumber).locationsInvested.indexOf(property2Chosen);
							players.get(playerNumber).locationsInvested.remove(index1);
							players.get(playerNumber).locationsInvested.add(index1, property1Chosen);
							((InvestmentSquare) boardPieces[property1Chosen]).setInvestor(playerNumber);



						}

						//Swap current players industry with player chosen
						if(players.get(playerNumberChosen).locationsInvested.contains(property1Chosen))
						{

							index2 = players.get(playerNumberChosen).locationsInvested.indexOf(property1Chosen);
							players.get(playerNumberChosen).locationsInvested.remove(index2);
							players.get(playerNumberChosen).locationsInvested.add(index2, property2Chosen);
							((InvestmentSquare) boardPieces[property1Chosen]).setInvestor(playerNumberChosen);


						}


						System.out.println("Trade completed"); 
					}
					if(entry.equalsIgnoreCase("no"))
					{


						System.out.println("Trade ended");

					}

				}


			}
		}

	}

	public void hacked(int playerNumber, ArrayList<Player> players)
	{
		Scanner sc = new Scanner(System.in);
		Random rand = new Random();
		int responseNumber = rand.nextInt(3);
		responseNumber++;

		//loops through all players in the game and checks if any players own a cyber security square
		for(int i = 0; i < players.size(); i++)
		{
			//prevents the current player from being able to help themselves with the breach if they own a cyber square. The loop only runs using the other players
			if(i != playerNumber)

			{
				for(int j = 0; j < players.get(i).getLocationsOwned().size(); j++)
					//check if the other players in the game own a cyber industry
					if(((InvestmentSquare) boardPieces[players.get(i).locationsInvested.get(j)]).getType() == industry.Cyber)
					{
						System.out.println("Player: " + players.get(i).getName() + " owns a cyber company and could help you with the data breach. "
								+ "Ask if they can help and enter yes or no: ");

						String entry = sc.nextLine();

						//if the player helps the current player (by entering yes) the switch statement is not run. If all cyber security owners choose not to help, the switch is run
						if(entry.equalsIgnoreCase("yes"))
						{
							responseNumber = 0;
							System.out.println("Player " + players.get(i).getName() + " has offered to help you " + " you have lost your turn but the hack has been resolved before damage occured");
							break;

						}
						else if(entry.equalsIgnoreCase("no"))
						{

							System.out.println("Player " + players.get(i).getName() + " has chosen not to help you");
						}
					}

			}

		}

		//taking a random response number and running the matching case
		switch (responseNumber)

		{
		case 1:
			System.out.println("No one can help you. The hack will continue...");
			System.out.println("------------------------------------------");
			System.out.println(" You have breached the Data Protection Act");
			System.out.println("    Hackers exploited a vulnerability in  ");
			System.out.println("    your server and stole 30,000 files    ");
			System.out.println("    containing users sensitive information");
			System.out.println("             Fine: 20 EpsiCoin            ");
			System.out.println("------------------------------------------");
			players.get(playerNumber).decreaseBalance(20);
			System.out.println("You now have " + players.get(playerNumber).getBalance() + "ε left");
			break;

		case 2:
			System.out.println("No one can help you. The hack will continue...");
			System.out.println("------------------------------------------");
			System.out.println(" One of your employees have lauched a DDos");
			System.out.println("    attack.Servers are currently down and ");
			System.out.println("    you must wait for the maintenance team");
			System.out.println("    to resolve all disruptions            ");
			System.out.println("           Costs incurred: 10 EpsiCoin    ");
			System.out.println("------------------------------------------");
			players.get(playerNumber).decreaseBalance(10);
			System.out.println("You now have " + players.get(playerNumber).getBalance() + " ε left");
			break;
		case 3:
			System.out.println("No one can help you. The hack will continue...");
			System.out.println("------------------------------------------");
			System.out.println("  One of your businesses have been targeted");
			System.out.println("  in a cyber attack attempted by          ");
			System.out.println("  hacktivist group anonymous              ");
			System.out.println("  They have taken down the company network");
			System.out.println("  employees can no longer perform duties  ");
			System.out.println("           Costs incurred: 15 EpsiCoin    ");
			System.out.println("------------------------------------------");
			players.get(playerNumber).decreaseBalance(15);
			System.out.println("You now have " + players.get(playerNumber).getBalance() + "ε left");
			break;

		}

	}

	// Asks player if they wish to invest in current square and handles lowering
	// player balance
	private void askToInvest(int location, int playerNumber) {
		Scanner sc = new Scanner(System.in); // brings in new scanner

		// check if square is owned, if owned deduct tax, if not owned ask to invest.
		if (((InvestmentSquare) boardPieces[location]).getInvested() == true) {

			taxPlayer(playerNumber, location);
		}

		// if square landed on is an investment square, and is not owned carry out else
		// clause to ask player to invest
		else {
			// check if the square landed on is not an investment square (Go,Null or Trade)
			if (((InvestmentSquare) boardPieces[location]).getID() == 3) {

				System.out.println("Landed on the Go square");

			}

			else if(((InvestmentSquare) boardPieces[location]).getID() == 1)
			{

				System.out.println("Landed on a trade square");
				trade(location, playerNumber);
			}

			else if(((InvestmentSquare) boardPieces[location]).getID() == 2)
			{

				System.out.println("Landed on a Null square, nothing happens...");

			}
			else if (((InvestmentSquare) boardPieces[location]).getID() == 4)
			{
				System.out.println("Landed on a Cyber Attack Square");
				hacked(playerNumber, players);
			}

			//if the square is not identified as an investment square, ask player to invest on the actual 
			//investment squares

			else
			{

				if(!(players.get(playerNumber).getBalance() < ((InvestmentSquare) boardPieces[location]).getPrice()))
				{

					System.out.println("Do you wish to invest in " + ((InvestmentSquare) boardPieces[location]).getName());
					System.out.println("The price of " + ((InvestmentSquare) boardPieces[location]).getName() + " is " + ((InvestmentSquare) boardPieces[location]).getPrice() + "ε" + " Enter Yes/No");
					String entry = sc.nextLine();

					if(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"))
					{

						do
						{
							System.out.println("Invalid option please enter again: ");
							entry = sc.nextLine();

						}
						while(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"));

					}


					if(entry.equalsIgnoreCase("no"))
					{
						System.out.println("You have chosen not to invest in " + ((InvestmentSquare) boardPieces[location]).getName());
						System.out.println("You have " + players.get(playerNumber).getBalance() +  "ε");
					}
					if (entry.equalsIgnoreCase("yes")) 
					{
						if (players.get(playerNumber).getBalance() - ((InvestmentSquare) boardPieces[location]).getPrice() < 0) // Checks to ensure purchasing the property won't bankrupt player.
						{
							System.out.println("You have " + players.get(playerNumber).getBalance() +  " EpsiCoin and do not have enough balance to afford this property!");
						} 

						else 
						{
							((InvestmentSquare) boardPieces[location]).setInvested(true); // Changes the variable in square named invested.
							((InvestmentSquare) boardPieces[location]).setInvestor(playerNumber); // Sets the investor to player ID.
							players.get(playerNumber).decreaseBalance(((InvestmentSquare) boardPieces[location]).getPrice()); // takes the price of the square out of players balance
							players.get(playerNumber).investIn(location); // invests in company, putting location in players company.

							players.get(playerNumber).locationsInvested.add(location);

							System.out.println("You now have " + players.get(playerNumber).getBalance() + "ε and you have successfully invested " + ((InvestmentSquare) boardPieces[location]).getName());

						}
					}

				}

				else
				{
					System.out.println("You cannot invest in " +  ((InvestmentSquare) boardPieces[location]).getName() +  " as you do not have enough balance!\n" + "You have " + players.get(playerNumber).getBalance()+"ε");
				}

			}
		}
	}




	// Moves player around the virtual board and handles checking if player wishes
	// to invest.
	public Square movePlayer(int playerNumber, int amount) 
	{
		if (players.get(playerNumber).playerLocation + amount >= boardPieces.length)			// checks if moving the player would go off of the board
		{

			// Loop the player around to the start of the board if they reach the end
			int temp = players.get(playerNumber).playerLocation + amount;

			temp = temp % boardPieces.length;

			players.get(playerNumber).setLocation(temp);		// loops the player back to start of board plus however much extra squares they moved past go.
			players.get(playerNumber).increaseBalance(20);		// IF PLAYER GOES PAST SQUARE ZERO AKA PASS GO ADD 20.
			System.out.println("You have passed go and earned 20ε coin!");
			System.out.println(players.get(playerNumber).getName() + "'s" + " current location is " + players.get(playerNumber).getLocation());

		}

		else 
		{
			players.get(playerNumber).setLocation(players.get(playerNumber).getLocation() + amount);
			System.out.println(players.get(playerNumber).getName() + "'s" + " current location is " + players.get(playerNumber).getLocation());
		}

		if (boardPieces[players.get(playerNumber).getLocation()] instanceof InvestmentSquare)			// IF SQUARE LANDED ON IS INVESTMENT SQUARE
		{
			//Call askToInvest method to allow the player to invest in the square or be taxed
			askToInvest(players.get(playerNumber).getLocation(), playerNumber);


		}

		//Check if the player has landed on a Crypto Mine square 
		if (boardPieces[players.get(playerNumber).getLocation()] instanceof CryptoSquare) 
		{
			((CryptoSquare) boardPieces[players.get(playerNumber).getLocation()]).cryptoOutcome(players.get(playerNumber), players);
		}



		return boardPieces[players.get(playerNumber).getLocation()];
	}


	public void checkWinner(ArrayList<Player> players, int playerNumber)
	{
		Scanner sc = new Scanner(System.in);

		//Take the player array list and see if the player meets the conditions, if one player is left and the rest have been
		//eliminated, execute the win condition or if the player with the most EpsiCoin wins.
		if(players.size() != 0)
		{

		}
		for (int j = 0; j < players.size(); j++)
		{

			if(players.get(j).getBalance() >= 350 || players.size() == 1)
			{  

				System.out.println("===========================================================");
				System.out.println("Player: " + players.get(j).getName() + " is the winner with " + players.get(j).getBalance() + "ε and the Technologies:");
				for(int i = 0; i < players.get(playerNumber).getLocationsOwned().size(); i++)
				{

					System.out.println(((InvestmentSquare) boardPieces[players.get(playerNumber).locationsInvested.get(i)]).getName());

				}
				System.out.println();
				System.out.println("Would you like to return to the Main Menu? Enter Yes/No");
				System.out.println("===========================================================");
				String entry = sc.nextLine();
				if(!entry .equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"))
				{

					do
					{
						System.out.println("Invalid option please enter again: ");
						entry = sc.nextLine();

					}
					while(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"));

				}


				if(entry.equalsIgnoreCase("yes"))
				{

					System.out.println("Returning to the Main Menu: ");
					Main.printMenu();
				}

				else if(entry.equalsIgnoreCase("no"))
				{

					System.out.println("Exiting the game....");
					System.exit(0);

				}
			}


		}

	}

	// Returns the player specified by ID
	public Player getPlayer(int numPlayer) 
	{
		return players.get(numPlayer);
	}

	// Returns the players location specified by ID
	public int getPlayerLocation(int numPlayer) 
	{
		return players.get(numPlayer).playerLocation;
	}

	public Square[] getBoardPieces() 
	{
		return boardPieces;
	}

	public ArrayList<Player> getPlayerArray() 
	{
		return players;
	}

}
