import java.util.ArrayList;
import java.util.Random;

public class CryptoSquare extends Square 
{
	private int squareID;
	private String squareName;

	GameHandler gameHandler;


	Random rand = new Random();
	int cryptoNumber = 0;

	public CryptoSquare() 
	{
		setSquareID(0);
		setSquareName("NULL");
	}

	public CryptoSquare(int squareID, String name) 
	{
		this.setSquareID(squareID);
		this.setSquareName(name);
	}

	public void showBalance(Player playerID)
	{
		if(playerID.getBalance() <= 0)
		{

			System.out.println("You have gone Bankrupt!");

		}

		else
		{

			System.out.println("You now have " + playerID.getBalance() + "ε");
		}
	}
	
	// This is the function that determines which random outcome occurs when a
	// player lands on a crypto mine
	public void cryptoOutcome(Player playerID, ArrayList<Player> players)
	{
		System.out.println("You have landed on the Crypto Mine! What outcome will you recieve?"); 

		cryptoNumber = rand.nextInt(12); // generates a number between 0-11
		cryptoNumber++; // makes it so that the range moves to 1-12

		switch (cryptoNumber)
		{
		case 1:
			System.out.println("---------------------------------------------");
			System.out.println("|                Crypto Mine                |");
			System.out.println("|                                           |");
			System.out.println("|         Your business implemented         |");
			System.out.println("|              quantum computers            |");
			System.out.println("|           Making mining efficient         |");
			System.out.println("|                                           |");
			System.out.println("|               You gained 10ε!             |");
			System.out.println("---------------------------------------------");

			playerID.increaseBalance(10);
			showBalance(playerID);

			break;
		case 2:
			System.out.println("---------------------------------------------");
			System.out.println("|                Crypto Mine                |");
			System.out.println("|                                           |");
			System.out.println("|    You found a complex cryptographic      |");
			System.out.println("|                 equation.                 |");
			System.out.println("|                                           |");
			System.out.println("|          If you solve it you gain         |");
			System.out.println("|    a random amount of Crypto EpsiCoins!   |");
			System.out.println("---------------------------------------------");

			int choice = rand.nextInt(30);

			if(choice != 0)
			{
				System.out.println("You solved the equation and gained " + choice + "ε");
				playerID.increaseBalance(choice);
				showBalance(playerID);
			}
			else
			{

				System.out.println("You didn't solve the cryptographic equation, you have gained 0ε");
				showBalance(playerID);
			}


			break;

		case 3:
			System.out.println("------------------------------------------");
			System.out.println("|               Crypto Mine              |");
			System.out.println("|                                        |");
			System.out.println("|       Your business has essential      |");
			System.out.println("|       Quantum Computer maintenance!    |");
			System.out.println("|                                        |");
			System.out.println("|             3ε per Business            |");
			System.out.println("------------------------------------------");

			//loop through locations invested to check how many a player owns, for each business decrease 3epsi
			int count = 0;
			for(int i = 0; i < playerID.locationsInvested.size(); i++)
			{

				if(playerID.locationsInvested.get(i) != -1)
				{
					count++;
					playerID.decreaseBalance(-3);	
				}
			}
			if(count == 0)
			{
				System.out.println("You own " + count + " technological businesses and do not have to pay");

			}
			else
			{
				System.out.println("You own " + count + " technological businesses and must pay " + 3*count + "ε");
				showBalance(playerID);

			}
			if(playerID.getBalance() <= 0)
			{

				System.out.println("You have gone Bankrupt!");
			}


			break;

		case 4:
			System.out.println("---------------------------------------------");
			System.out.println("|                Crypto Mine                |");
			System.out.println("|                                           |");
			System.out.println("|   A random player owes you 20% of their   |");
			System.out.println("|                                           |");
			System.out.println("|               Cryto EpsiCoins             |");
			System.out.println("|                                           |");
			System.out.println("---------------------------------------------");


			int player = rand.nextInt(players.size());
			int total = 0;

			total = (int) (players.get(player).getBalance() * 0.2);

			if(players.get(player) != playerID)
			{
				System.out.println (players.get(player).getName() + " Owes you" + total + "ε");
				playerID.increaseBalance(total);
				players.get(player).decreaseBalance(total);
				showBalance(playerID);
				System.out.println("Player: " + players.get(player).getName() + " now has " + players.get(player).getBalance() + "ε");
			}

			else
			{

				System.out.println("You were chosen randomly and have lost 20% of your crypto EpsiCoins" + " you lost " + total + "ε");
				playerID.decreaseBalance(total);
				showBalance(playerID);

			}




			break;

		case 5:

			System.out.println("--------------------------------------------");
			System.out.println("|               Crypto Mine                |");
			System.out.println("|                                          |");
			System.out.println("|   You got caught sharing confidential    |");
			System.out.println("| cryptographic algorithms from the mines! |");
			System.out.println("|                                          |");
			System.out.println("|              You lost 10ε!               |");
			System.out.println("--------------------------------------------");

			playerID.decreaseBalance(10);
			showBalance(playerID);

			break;

		case 6:

			System.out.println("---------------------------------------------");
			System.out.println("|                Crypto Mine                |");
			System.out.println("|                                           |");
			System.out.println("|     You have been caught evading tax      |");
			System.out.println("|          on your crypto currency          |");
			System.out.println("|                                           |");
			System.out.println("|               You lost 15ε!               |");
			System.out.println("---------------------------------------------");

			playerID.decreaseBalance(15);
			showBalance(playerID);


			break;

		case 7:

			System.out.println("--------------------------------------------");
			System.out.println("|                Crypto Mine               |");
			System.out.println("|                                          |");
			System.out.println("|    Power loss has ocurred in the city    |");
			System.out.println("|                                          |");
			System.out.println("|    You cannot mine for cryptocurrency!   |");
			System.out.println("|                                          |");
			System.out.println("|               You lost 12ε!              |");
			System.out.println("--------------------------------------------");

			playerID.decreaseBalance(12);
			showBalance(playerID);


			break;

		case 8:

			System.out.println("------------------------------------------");
			System.out.println("|               Crypto Mine              |");
			System.out.println("|                                        |");
			System.out.println("|    One of your companies had a fire    |");
			System.out.println("|         a player had to help you       |");
			System.out.println("|                                        |");
			System.out.println("|       Mining operations have halted    |");
			System.out.println("|               You lost 5ε!             |");
			System.out.println("------------------------------------------");

			playerID.decreaseBalance(16);
			showBalance(playerID);


			break;

		case 9:

			System.out.println("------------------------------------------");
			System.out.println("|               Crypto Mine              |");
			System.out.println("|                                        |");
			System.out.println("|    Your industry had a Technological   |");
			System.out.println("|      breakthrough. Mining is faster!   |");
			System.out.println("|                                        |");
			System.out.println("|             You gained 20ε!            |");
			System.out.println("------------------------------------------");

			playerID.increaseBalance(20);
			showBalance(playerID);

			break;

		case 10:

			System.out.println("------------------------------------------");
			System.out.println("|                Crypto Mine             |");
			System.out.println("|                                        |");
			System.out.println("|         Your computer broke down!      |");
			System.out.println("|              can you fix it?           |");
			System.out.println("|                                        |");
			System.out.println("|                                        |");
			System.out.println("------------------------------------------");

			boolean fixComputer = rand.nextBoolean();

			if(fixComputer)
			{
				System.out.println("Fortunately you were able to fix your computer, your mining oepration identified hidden cryptocurrency you have earned 8ε");
				playerID.increaseBalance(8);
				showBalance(playerID);
			}
			else
			{
				System.out.println("You were unable to fix your computer, you have lost 8ε as someone else solved your cryptogrpahic equation in the mine");
				playerID.decreaseBalance(8);
				showBalance(playerID);
			}


			break;

		case 11:

			System.out.println("-------------------------------------------");
			System.out.println("|               Crypto Mine               |");
			System.out.println("|                                         |");
			System.out.println("|          A white hat hacker finds       |");
			System.out.println("|     vulnerabilities in your system      |");
			System.out.println("| and fixes them, your crypto currency is |");
			System.out.println("|            protected from theives       |");
			System.out.println("|                                         |");
			System.out.println("|              You gained 10ε!            |");
			System.out.println("-------------------------------------------");

			playerID.increaseBalance(10);
			showBalance(playerID);

			break;

		case 12:

			System.out.println("----------------------------------------------");
			System.out.println("|                Crypto Mine                 |");
			System.out.println("|                                            |");
			System.out.println("|        You have been targeted by an        |");
			System.out.println("|      external hacker, they stole some      |");
			System.out.println("|       cryptocurrency from your wallet!     |");
			System.out.println("|                                            |");
			System.out.println("|                You lost 25ε!               |");
			System.out.println("----------------------------------------------");


			playerID.decreaseBalance(25);
			showBalance(playerID);

			break;
		}

	}



	public int getSquareID() {
		return squareID;
	}

	public void setSquareID(int squareID) {
		this.squareID = squareID;
	}

	public String getSquareName() {
		return squareName;
	}

	public void setSquareName(String squareName) {
		this.squareName = squareName;
	}

}
