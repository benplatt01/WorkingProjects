import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;


public class GameHandler {


	Board gameBoard;
	int playerTurn = 1;
	public int amount = 0;
	boolean gameActive;
	Company company;
	ArrayList<Player> players = new ArrayList<Player>(amount);


	public GameHandler() {
		gameBoard = new Board();
		gameBoard.setPlayers(createPlayers());
		gameActive = true;
	}

	private ArrayList<Player> createPlayers() {
		Company[] companies;
		Scanner scanner = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		System.out.print("How many players are there?: ");
		amount = 0;

		// Input validation checking if a non integer or integer not between 2 and 8 has
		// been entered
		while (amount <= 1 || amount >= 9) {

			try {
				System.out.print("Please enter a number between 2 and 8: ");
				amount = scanner.nextInt();
			}

			catch (InputMismatchException e) {
				scanner.nextLine();
			}
		}

		companies = new Company[amount];

		for (int i = 0; i < amount; i++) {

			System.out.println("Player " + (i + 1));
			System.out.println("Please enter your name: ");
			String name = sc.nextLine();
			for (Player player : players) {

				if (player != null && name.equalsIgnoreCase(player.getName())) {
					String newName;
					do {
						System.out.println("Please enter your name again as it is the same as the previous player");
						newName = sc.nextLine();
					} while (newName.equalsIgnoreCase(name));
					name = newName;
				}
			}

			System.out.println("Please enter your company name: ");
			String companyName = sc.nextLine();

			for (Company company : companies) {
				if (company != null && companyName.equalsIgnoreCase(company.getCompanyName())) {
					String newCompany;
					do {
						System.out.println("Please enter your name again as it is the same as the previous player");
						newCompany = sc.nextLine();
					} while (newCompany.equalsIgnoreCase(companyName));
					companyName = newCompany;
				}
			}

			Company newCompany = new Company(companyName, i);
			Player newPlayer = new Player(name, newCompany);
			players.add(newPlayer);
			companies[i] = newCompany;
		}

		return players;
	}

	// Handle each players turn, will need updated to change player options based on
	// the players statistics.
	public void playerTurn(int playerNumber) {
		int menuOptions = 6;
		int entry = 0;
		Scanner sc = new Scanner(System.in);


		do {


			gameBoard.checkWinner(players, playerNumber); 
			gameBoard.technopolisation(playerNumber, entry);



			// Loop through players and check if it is the last player then return to player
			// one
			if (players.get(playerNumber).turnComplete && ++playerNumber >= amount) {
				playerNumber = 0;

			}


			//Display the current players menu options
			System.out.println("\n===========================================================");
			System.out.println("It is now " + gameBoard.getPlayer(playerNumber).getName() + "'s turn, you have: "
					+ gameBoard.getPlayer(playerNumber).getBalance() + " points in your balance.");
			System.out.println(
					"You can choose from the following: \n1. Roll Dice\n2. View Owned Properties\n3. Show Help\n4. Exit Game\n5. Display the board\n6. Display the LeaderBoard");

			//Check if the player has unlocked Declare Bankruptcy
			if(players.get(playerNumber).getBalance() <= 20)
			{
				players.get(playerNumber).bankruptAvailable = true;
				System.out.println("7. Declare Bankruptcy");
				menuOptions = 7;

			}
			if(players.get(playerNumber).getBalance() <= 0)
			{
				System.out.println();
				players.get(playerNumber).turnComplete = true;
				System.out.println("You have went Bankrupt! You have been eliminated from the game");
                removePlayerFromGame(players, playerNumber);
			}
			else if(players.get(playerNumber).getBalance() > 20)
				players.get(playerNumber).bankruptAvailable = false;


			//Check if the player has unlocked Monopolisation
			if(players.size()!= 1)
			{
				if(players.get(playerNumber).monopolisationAvailable)
				{
					System.out.println(
							"8. Technopolisation");
					menuOptions = 8;

				}

			}

			System.out.println("===========================================================");

			// Input validation to check invalid option has not been entered
			do {
				try {

					System.out.print("Please enter a number from the options: ");
					entry = sc.nextInt();
				}

				catch (InputMismatchException e) {

					sc.nextLine();

				}

			} while (entry <= 0 || entry > menuOptions);


			{
				switch (entry) {
				case 1:
					gameBoard.movePlayer(playerNumber, diceRoll());
					players.get(playerNumber).turnComplete = true;
					break;

				case 2:
					printProperties(gameBoard.getPlayer(playerNumber));
					players.get(playerNumber).turnComplete = false;
					break;

				case 3:
					printHelp(playerNumber);
					players.get(playerNumber).turnComplete = false;
					break;

				case 4:
					System.out.println("Returning to the Main Menu");
					gameActive = false;
					players.get(playerNumber).turnComplete = true;
					break;
				case 5:
					System.out.println("Printing the board layout...");
					printLayout();
					players.get(playerNumber).turnComplete = false;
					break;
				case 6:
					players.get(playerNumber).turnComplete = false;
					printLeaderBoard(players);
				case 7:
					if(players.get(playerNumber).bankruptAvailable)
					{
						players.get(playerNumber).turnComplete = true;
						declareBankruptcy(players, playerNumber);
						break;
					}
				case 8:
					if(players.get(playerNumber).monopolisationAvailable)
					{
						players.get(playerNumber).turnComplete = true;
						gameBoard.technopolisation(playerNumber, entry); 
						break;
					}

				default:


				}
			}

		} while (gameActive == true);

	}



	//find the player with the highest balance and loop through to find the second highest. Print the leaderboard 
	public void printLeaderBoard(ArrayList<Player> players)
	{
		System.out.println("===========================================================");
		System.out.println("The LeaderBoard");
		int highestBalance = -1;
		ArrayList<Player> leaderBoard = new ArrayList<>();
		Player playerWithHighestBalance = null;
		for (int i = 0; i < players.size(); i++)
		{
			for(int j = 0; j < players.size(); j++)
			{  	        	
				if(players.get(j).getBalance() > highestBalance && !leaderBoard.contains(players.get(j)))
				{
					highestBalance = players.get(j).getBalance();
					playerWithHighestBalance = players.get(j);   				
				}		
			}
			leaderBoard.add(playerWithHighestBalance);
			highestBalance = -1;
			playerWithHighestBalance = null;
		}

		for (int i = 0; i < leaderBoard.size(); i++) {
			System.out.println(i + 1 + ") " + leaderBoard.get(i).getName() + " has the balance " + leaderBoard.get(i).getBalance());
		}
		System.out.println("===========================================================");
		System.out.println("Press \"ENTER\" to continue...");
		Scanner scanner = new Scanner(System.in);
		scanner.nextLine();
	}

	public void declareBankruptcy(ArrayList<Player> players, int playerNum) {


		if(players.get(playerNum).bankruptAvailable)
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("You can declare bankruptcy, you will lose all invested Technologies and Technopolisations");
			System.out.println("Would you like to continue? Enter Yes/No If you select no you will be removed from the game");


			String entry = sc.nextLine();

			if(!entry .equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"))
			{

				do
				{
					System.out.println("Invalid option please enter again: ");
					entry = sc.nextLine();

				}
				while(!entry.equalsIgnoreCase("yes") && !entry.equalsIgnoreCase("no"));

			}

			if(entry.equalsIgnoreCase("no"))
			{
				System.out.println("You have chosen not to declare bankruptcy, you will now be removed from the game");
				removePlayerFromGame(players, playerNum);
				
			}


			//Reset the players stats and give them 100 epsicoins
			else if (entry.equalsIgnoreCase("yes")) 
			{
				System.out.println("You have chosen to declare bankrupty, you now have 100ε and no owned Technologies");

				players.get(playerNum).monoAI = false;
				players.get(playerNum).monoCyber = false;
				players.get(playerNum).monoDS = false;
				players.get(playerNum).monoFI = false;
				players.get(playerNum).monoGD = false;
				players.get(playerNum).monoRD = false;
				players.get(playerNum).monoSD = false;
				players.get(playerNum).monoVR = false;

				for(int i = 0; i < players.get(playerNum).locationsInvested.size(); i++)
				{

					((InvestmentSquare) gameBoard.boardPieces[players.get(playerNum).locationsInvested.get(i)]).setInvested(false);
					((InvestmentSquare) gameBoard.boardPieces[players.get(playerNum).locationsInvested.get(i)]).setInvestor(-1);
					((InvestmentSquare) gameBoard.boardPieces[players.get(playerNum).locationsInvested.get(i)]).setBuildingLevel(0);
					players.get(playerNum).bankruptAvailable = false;
					players.get(playerNum).locationsInvested.remove(i);

				}

				players.get(playerNum).setBalance(100);
				players.get(playerNum).turnComplete = true;
			}


		}
		gameBoard.checkWinner(players, playerNum);

	}

	public void removePlayerFromGame(ArrayList<Player> players, int playerNum)
	{
		System.out.println("Thank you for playing! Player: " + players.get(playerNum).getName() + " Goodbye for now...");

		players.get(playerNum).monoAI = false;
		players.get(playerNum).monoCyber = false;
		players.get(playerNum).monoDS = false;
		players.get(playerNum).monoFI = false;
		players.get(playerNum).monoGD = false;
		players.get(playerNum).monoRD = false;
		players.get(playerNum).monoSD = false;
		players.get(playerNum).monoVR = false;

		for(int i = 0; i < players.get(playerNum).getLocationsOwned().size(); i++)
		{

			((InvestmentSquare) gameBoard.boardPieces[players.get(playerNum).locationsInvested.get(i)]).setInvested(false);
			((InvestmentSquare) gameBoard.boardPieces[players.get(playerNum).locationsInvested.get(i)]).setInvestor(-1);
			((InvestmentSquare) gameBoard.boardPieces[players.get(playerNum).locationsInvested.get(i)]).setBuildingLevel(0);
			players.get(playerNum).bankruptAvailable = false;
			players.get(playerNum).locationsInvested.remove(i);

		}

		//When player is removed from the array list, deduct the total player amount to prevent indexOutofBounds exception
		players.remove(playerNum);
		amount--;

		for(int j = 0; j < players.size(); j++)
		{
			System.out.println("Players left in the game: " + players.get(j).getName() + " Company: " + players.get(j).getCompany().companyName);

		}
		gameBoard.checkWinner(players, playerNum);
	}



	public void printHelp(int playerNumber) {
		System.out.println("\n===========================================================");
		System.out.println("Here is the Handy Help Guide " + players.get(playerNumber).getName());
		System.out.println();
		System.out.println("How to play:");
		System.out.println("1. State how many players and enter name and company names for each player, a player cannot have the same names as another");
		System.out.println();
		System.out.println("2. Select play game from the menu");
		System.out.println(
				"\n3. On your turn you always have the option to roll dice, view owned properties, show help, exit game and display the board.\n   Declare Bankruptcy ocurrs when a player has zero or less than 20 EpsiCoins. Technopolisation occurrs if a player reinvests\n   into their Technology four times, these can be unlocked.");
		System.out.println();
		System.out.println(
				"4. If you land on a free company space you will have the option to invest in that company, if you own all Technological businesses\n   within that industry your revenue will increase as will the cost for other players who land on your company.");
		System.out.println();
		System.out.println(
				"5. When a player lands on a Technological company owned by another player they will be taxed, and this goes to the owner.\n   Tax increases each time you reinvest into your business as you add a Server.\n   If an entire industry has servers they can build a Quantum Computer to aid with Crypto Mining.");
		System.out.println();
		System.out.println(
				"6. In order to declare bankruptcy a player must be below 20 EpsiCoins or it occurrs automatically when reaching 0 EpsiCoin.\n   If you choose yes then you will recieve 100 EpsiCoins but will lose all owned Technologies\n   If you choose no you will be eliminated from the game.");
		System.out.println();
		System.out.println("7. A player can  trade Technologies with others if they land on a Trade square");
		System.out.println("\n8. Cryto mines have a chance of being positive or negative for the player, your company can mine for cryptocurrency\n   to gain more EpsiCoins");
		System.out.println();
		System.out.println("9. A player is deemed the winner of Technopoly if all other players have been eliminated or if a player has reached 350 EpsiCoins");
		System.out.println("===========================================================");
		System.out.println("Press \"ENTER\" to continue...");
		Scanner sc = new Scanner(System.in);
		sc.nextLine();
	}

	private void printProperties(Player player) {
		int counter = 0;
		for (int i = 0; i < player.locationsInvested.size(); i++) {
			{
				counter++;
				System.out.println(counter + ". "
						+ ((InvestmentSquare) gameBoard.boardPieces[player.locationsInvested.get(i)]).getName());

			}
		}
		if (counter == 0) {
			System.out.println("\nNo Owned Properties");
		}
	}

	private int diceRoll() 
	{
		Random random = new Random();
		int roll1;
		int roll2;

		roll1 = random.nextInt(6) + 1; roll2 = random.nextInt(6) + 1; 

		System.out.println("Dice One you rolled: " + roll1 + "\n" + "Dice Two you rolled: " + roll2 +  "\n" +  "You will move " + (roll1 + roll2) + " times");
		System.out.println();
		return roll1 + roll2;
	}

	public static void printLayout()
	{
		try 
		{
			File myObj = new File("boardgamelayout.txt");
			Scanner myReader = new Scanner(myObj);
			while(myReader.hasNextLine())
			{
				String data = myReader.nextLine();
				System.out.println(data);
			}
			myReader.close();
		} catch(FileNotFoundException e) {
			System.out.println("error file not found");
			e.printStackTrace();
		}

		System.out.println("Expand the console to view the board");

		System.out.println("Press \"ENTER\" to continue...");
		Scanner sc = new Scanner(System.in);
		sc.nextLine();


	}

}

