import java.util.Scanner;		
public class Main 
{

	public static void main(String[] args) 
	{
		printMenu();
	}

	public static void game() 
	{
		GameHandler game = new GameHandler();
		game.playerTurn(0);
	}

	public static void rule() 
	{
		printHelp();
	}

	public static void enterContinue() 
	{
		System.out.println("Press \"ENTER\" to continue...");
		Scanner scanner = new Scanner(System.in);
		scanner.nextLine();

		printMenu();
	}

	public static int userInput() 
	{
		int num = 0;                                                                                                    
		String strInput;                                                                                               
		boolean valid = false;                                                                                          

		Scanner in = new Scanner(System.in);                                                                            

		while (!valid) 
		{                                                                                                				
			System.out.println("Please enter in a number between 1 and 3: ");                                          
			strInput = in.nextLine();                                                                                   

			try {                                                                                                       
				num = Integer.parseInt(strInput);                                                                       
				valid = true;                                                                                           
			} catch (NumberFormatException e) 
			{                                                                         									
				System.out.println("Please enter an integer: ");                                                       
				enterContinue();
				printMenu();                                                                                            
			}

		}
		return num;                                                                                                     // Returns the integer from user input which can be
	}

	public static void printMenu() {
		System.out.println("+-----------------------------------+");
		System.out.println("|        Welcome to Technopoly      |");
		System.out.println("+-----------------------------------+");
		System.out.println("|      Please Choose an option:     |");
		System.out.println("+-----------------------------------+");
		System.out.println("|        1.     Play                |");
		System.out.println("|        2.   Game Rules            |");
		System.out.println("|        3.     Exit                |");
		System.out.println("+-----------------------------------+");

		int choiceEntry = userInput();

		while (choiceEntry != 4) 
		{

			if (choiceEntry < 1 || choiceEntry > 3) 
			{
				System.out.println("Please enter a number between 1 and 3: ");
				enterContinue();
				printMenu();

			} else if (choiceEntry == 1) 
			{
				System.out.println("Starting Game...");
				game();
				enterContinue();
			} else if (choiceEntry == 2) 
			{
				rule();
				enterContinue();
				printMenu();

			} else if (choiceEntry == 3) 
			{
				System.out.println("Exiting the game....");
				System.out.println("The game has ended, you can now close it");
				System.exit(0);
			}
		}
	}
	public static void printHelp()
	{
		System.out.println("\n===========================================================");
		System.out.println("How to play:");
		System.out.println("1. State how many players and enter name and company names for each player, a player cannot have the same names as another");
		System.out.println();
		System.out.println("2. Select play game from the menu");

		System.out.println(
				"\n3. On your turn you always have the option to roll dice, view owned properties, show help, exit game and display the board.\n   Declare Bankruptcy ocurrs when a player has zero or less than 20 EpsiCoins. Technopolisation occurrs if a player reinvests\n   into their Technology four times, these can be unlocked.");
		System.out.println();
		System.out.println(
				"4. If you land on a free company space you will have the option to invest in that company, if you own all Technological businesses\n   within that industry your revenue will increase as will the cost for other players who land on your company.");
		System.out.println();
		System.out.println(
				"5. When a player lands on a Technological company owned by another player they will be taxed, and this goes to the owner.\n   Tax increases each time you reinvest into your business as you add a Server.\n   If an entire industry has servers they can build a Quantum Computer to aid with Crypto Mining.");
		System.out.println();
		System.out.println(
				"6. In order to declare bankruptcy a player must be below 20 EpsiCoins or it occurrs automatically when reaching 0 EpsiCoin.\n   If you choose yes then you will recieve 100 EpsiCoins but will lose all owned Technologies\n   If you choose no you will be eliminated from the game.");
		System.out.println();
		System.out.println("7. A player can  trade Technologies with others if they land on a Trade square");
		System.out.println("\n8. Cryto mines have a chance of being positive or negative for the player, your company can mine for cryptocurrency\n   to gain more EpsiCoins");
		System.out.println();
		System.out.println("9. A player is deemed the winner of Technopoly if all other players have been eliminated or if a player has reached 350 EpsiCoins");
		System.out.println("===========================================================");
	}



}


