
public abstract class Square 
{
	int squareID;		//declaring the int variable squareID
	String squareName;		//declaring the String variable squareName
}
