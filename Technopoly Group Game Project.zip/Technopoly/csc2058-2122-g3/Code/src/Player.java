import java.util.ArrayList;

public class Player 
{

	String name;
	int playerLocation, balance;	
	ArrayList<Integer> locationsInvested = new ArrayList<Integer>();

	Company playerCompany;
	boolean turnComplete = false;
	boolean bankruptAvailable = false;

	//Technopolisation check to prevent a player from technopolising more than once
	boolean monopolisationAvailable = false;
	boolean monoSD = false;
	boolean monoDS = false;
	boolean monoVR = false;
	boolean monoCyber = false;
	boolean monoGD = false;
	boolean monoAI = false;
	boolean monoFI = false;
	boolean monoRD = false;


	public Player(String m_name, Company m_company)
	{
		playerLocation = 0;	
		balance = 200;		
		this.name = m_name;		
		this.playerCompany = m_company;

	}

	//Getters and setters to set and retrieve variables
	public void investIn(int location) 
	{
		playerCompany.makeInvestment(location);
	}

	public void setName(String n_name)
	{
		this.name = n_name;
	}

	public String getName()		
	{
		return this.name;
	}

	public void setCompany(Company n_company)		
	{
		this.playerCompany = n_company;
	}

	public Company getCompany()		
	{
		return this.playerCompany;
	}

	public int getBalance()		
	{
		return this.balance;
	}

	public void increaseBalance(int amount)		
	{
		this.balance += amount;
	}

	public void decreaseBalance(int amount)		
	{
		this.balance -= amount;
	}

	public void setBalance(int amount)	
	{
		this.balance = amount;
	}

	public void setLocation(int location)	
	{
		this.playerLocation = location;
	}

	public int getLocation()		
	{
		return this.playerLocation;
	}

	public ArrayList<Integer> getLocationsOwned()		
	{
		return this.locationsInvested;
	}

	public void setLocationsOwned(ArrayList<Integer> locations)
	{
		this.locationsInvested = locations;
	}
}
